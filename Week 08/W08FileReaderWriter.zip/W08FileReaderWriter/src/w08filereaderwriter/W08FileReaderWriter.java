/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w08filereaderwriter;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;
/**
 *
 * @author omalleym
 */
public class W08FileReaderWriter 
{
    private static ArrayList<String> namesArrayList = new ArrayList<String>(); 
    
    
    public static void readFile()
    {

        // Try with resources - you do NOT need to worry about finally, 
        // closing the file, etc
        try (Scanner inFile = new Scanner (new FileReader ("file.txt")); )
        //try
        {
          //  Scanner inFile = new Scanner (new FileReader ("file.txt"));

            namesArrayList.clear();
            
            while (inFile.hasNext() == true)
            {
                namesArrayList.add (inFile.next() );
            }
        }
        catch (Exception err)
        {
            System.out.println ("ERROR: file count not be read.");
            err.printStackTrace();
        }
        /*
        finally
        {
            if (inFile != null)
            {
                inFile.close();
            }
        }
        */
    }
    
    public static void writeFile ()
    {
        // Try with resources - Java automatically closes the file for us !!
        try (Formatter outFile = new Formatter ("file.txt") )
        {
            for (String s: namesArrayList)
            {
                outFile.format (s + "\n");
            }
        }
        catch (Exception err)
        {
            System.out.println ("ERROR: file count not be read.");
            err.printStackTrace();
        }
    }
    
    public static void displayArrayList ()
    {
        for (String s: namesArrayList)
        {
            System.out.println (s);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        namesArrayList.add ("Mike");
        namesArrayList.add ("Frankie");
        namesArrayList.add ("Bella");
        
        writeFile();
        
        namesArrayList.clear(); // To prove the readFile works below !
        
        readFile();
        displayArrayList ();
    }
    
}
