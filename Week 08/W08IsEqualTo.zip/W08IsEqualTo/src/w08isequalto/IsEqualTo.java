/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w08isequalto;

/**
 *
 * @author omalleym
 */
public class IsEqualTo 
{
/*
    // test whether two generic types are equal
    public static < T > boolean isEqualTo( T first, T second )
    {
        // complete missing codes
        // TODO: Check for nulls

        return first.equals(second);
    } // end method isEqualTo
*/    

    // test whether two generic types are equal
    public static < T,U > boolean isEqualTo( T first, U second )
    {
        // complete missing codes
        // TODO: Check for nulls
        // TODO: Check data types
        // TODO: Compare values
        boolean result = false; // Not the same !
        
        if ((first == null) && (second == null) )
        {
            result = true; // Both are null
        }
        else if (first == null)
        {
            result = false; // only first is null
        }
        else if (second == null)
        {
            result = false; // only second is null
        }
        else
        {
            /*
            if ((first instanceof U) && (second instanceof T)
            {
                
            }
            */
            
            String firstClassNameStr  = first.getClass().getName();
            String secondClassNameStr = second.getClass().getName();
            
            if (firstClassNameStr.compareTo (secondClassNameStr) == 0)
            {
                // Classes are the same.
                // Let's compare the data !
                
                result = first.equals (second);
            }
        }

        return result;
    } // end method isEqualTo


}
