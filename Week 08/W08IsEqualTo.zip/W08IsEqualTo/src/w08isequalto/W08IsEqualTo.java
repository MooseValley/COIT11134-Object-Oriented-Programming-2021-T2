/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w08isequalto;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W08IsEqualTo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        String name1 = "Mike";
        String name2 = "Frankie";
        String name3 = "Mike";
        String name4 = null;
        String name5 = null;
        
        System.out.println (name1 + " = " + name2 + ": " + 
            IsEqualTo.isEqualTo (name1, name2) );

        System.out.println (name1 + " = " + name3 + ": " + 
            IsEqualTo.isEqualTo (name1, name3) );

        // Nulls:
        System.out.println (name1 + " = " + name4 + ": " + 
            IsEqualTo.isEqualTo (name1, name4) );

        System.out.println (name4 + " = " + name5 + ": " + 
            IsEqualTo.isEqualTo (name4, name5) );
        
        
        Double d1 = 3.3;
        Double d2 = 4.7;
        Double d3 = 4.7;

        System.out.println (d1 + " = " + d2 + ": " + 
            IsEqualTo.isEqualTo (d1, d2) );

        System.out.println (d2 + " = " + d3 + ": " + 
            IsEqualTo.isEqualTo (d2, d3) );

        
        // Different Data Types:
        System.out.println (d2 + " = " + name1 + ": " + 
            IsEqualTo.isEqualTo (d2, name1) );
    
        Integer i1 = 4;
        Double  d4 = (double) 4;
        System.out.println (i1 + " = " + d4 + ": " + 
            IsEqualTo.isEqualTo (i1, d4) );
        
        


      Scanner scanner = new Scanner( System.in );

      Integer a; // Integers used for
      Integer b; // testing equality

      // test if two Integers input by user are equal
      System.out.print( "Enter two integer values: " );
      a = scanner.nextInt(); // get first integer
      b = scanner.nextInt(); // get second integer
      System.out.printf( "%d and %d are %s\n", a, b,
         ( IsEqualTo.isEqualTo( a, b ) ? "equal" : "not equal" ) );

        /* Declare two String variables; receive their values from user input and test whether they are equal 
        */
        // declaring String variables
      String c; // Strings used for
      String d; // testing equality

      // test if two Strings input by user are equal
      // …… complete missing codes
      System.out.print( "Enter two String values: " );
      c = scanner.next(); // get first String
      d = scanner.next(); // get second String
      System.out.printf( "%s and %s are %s\n", c, d,
         ( IsEqualTo.isEqualTo( c, d ) ? "equal" : "not equal" ) );
      
      
      /* Declare two Double variables; receive their values from user input and test whether they are equal 
      */
      //declare two Double variables
      // …… complete missing codes
      // test if two Doubles input by user are equal
      // …… complete missing codes

      Double d8; // Doubles used for
      Double d9; // testing equality

      // test if two Integers input by user are equal
      System.out.print( "Enter two Double values: " );
      d8 = scanner.nextDouble(); // get first Double
      d9 = scanner.nextDouble(); // get second Double
      System.out.printf( "%f and %f are %s\n", d8, d9,
         ( IsEqualTo.isEqualTo( d8, d9 ) ? "equal" : "not equal" ) );
    
    } // end main
    
}
