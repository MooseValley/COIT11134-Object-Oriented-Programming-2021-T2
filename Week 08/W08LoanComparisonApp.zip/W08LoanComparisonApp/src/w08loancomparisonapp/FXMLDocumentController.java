/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w08loancomparisonapp;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable, IExitable
{
    @FXML
    private TextField txtPrincipleFirst;
    @FXML
    private TextField txtPeriodFirst;
    @FXML
    private TextField txtInterestRateFirst;
    @FXML
    private TextField txtAnnualFeesChargesFirst;
    @FXML
    private TextField txtPeriodSecond;
    @FXML
    private TextField txtInterestRateSecond;
    @FXML
    private TextField txtAnnualFeesChargesSecond;
    @FXML
    private TextArea taResult;
    @FXML
    private Button btnCompare;
    @FXML
    private Button btnExit;
    @FXML
    private Button btnTestData;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnCompareHandler(ActionEvent event) 
    {
        //get values from the user entry for first Loan
        double p = Double.parseDouble(txtPrincipleFirst.getText());
        int num = Integer.parseInt(txtPeriodFirst.getText());
        double i = Double.parseDouble(txtInterestRateFirst.getText());
        double txtAnnualFeesCharges = Double.parseDouble(this.txtAnnualFeesChargesFirst.getText());

        //create first Loan and display
        Loan firstLoan = new Loan (p,i, num,txtAnnualFeesCharges);
        this.taResult.setText("Loan 1 \n" +firstLoan.toString());


        //get values from the user entry for second Loan
        //missing lines of code to be completed

        double p2 = Double.parseDouble(txtPrincipleFirst.getText());
        int num2 = Integer.parseInt(txtPeriodSecond.getText());
        double i2 = Double.parseDouble(txtInterestRateSecond.getText());
        double txtAnnualFeesCharges2 = Double.parseDouble(this.txtAnnualFeesChargesSecond.getText());

        //create second Loan and display
        //missing lines of code to be completed
        Loan secondLoan = new Loan (p2, i2, num2, txtAnnualFeesCharges2);
        this.taResult.appendText("\nLoan 2 \n" + secondLoan.toString());

        
        this.taResult.appendText("\n");
        //compare the loans and display       
        if(firstLoan.compareTo(secondLoan)>0)
           this.taResult.appendText("Loan 2 is better");
        if(firstLoan.compareTo(secondLoan)<0)
           this.taResult.appendText("Loan 1 is better");
        if(firstLoan.compareTo(secondLoan)== 0)
           this.taResult.appendText("Loan 1 and Loan 2 are equivalent");
    }

    @FXML
    private void btnExitHandler(ActionEvent event) 
    {
        this.exitClick(); 
    }

    @FXML
    private void btnTestDataHandler(ActionEvent event) 
    {
        
        txtPrincipleFirst.setText ("1000");
        txtPeriodFirst.setText ("1");
        txtInterestRateFirst.setText ("12");
        txtAnnualFeesChargesFirst.setText ("100");
        
        txtPeriodSecond.setText ("1");
        txtInterestRateSecond.setText ("10");
        txtAnnualFeesChargesSecond.setText ("150");
    }
   
}
