/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w08genericprintarray;

/**
 *
 * @author omalleym
 */
public class W08GenericPrintArray 
{
    public static <T extends Comparable> void printArray (T[] inArray)
    {
        printArray (inArray, 0, inArray.length - 1);
        /*
        if (inArray != null)
        {
            for (T value : inArray)
            {
                System.out.println (value);
            }
        }
        */
    }

    public static <T extends Comparable> void printArray (T[] inArray, int fromIndex, int toIndex)
    {
        if (inArray != null)
        {
            if ((fromIndex >=0) && (fromIndex <= toIndex) && (toIndex < inArray.length) )
            {
                for (int k = fromIndex; k <= toIndex; k++)
                {
                    System.out.println (inArray[k]);
                }
            }
            else
            {
                System.out.println ("ERROR: Index(es) out of bounds:" +
                    " Expected: index values between 0-" + (inArray.length - 1) +
                    " inclusive, but received index values: " + 
                    fromIndex + " and " + toIndex + "." );
            }
        }
        else
        {
            System.out.println ("ERROR: array is null.");
        }
    }

    /*    
    public static void printArray (int[] inArray)
    {
        if (inArray != null)
        {
            for (int k = 0; k < inArray.length; k++)
            {
                System.out.println (inArray[k]);
            }
        }
    }
*/    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        String[] array1 = null;
        printArray (array1);

        String[] names = {"Moose", "Frankie", "Bella", "Sam"};
        printArray (names);
        printArray (names, 3, 9);
        printArray (names, 1, 2);
        
        Integer[] intArray = {4, 5, 6, 99, -33};
        printArray (intArray);

        Double[] doubleArray = {1.4, 2.5, 3.6, 9.9, -8.03};
        printArray (doubleArray);

        Character[] charArray = {'A', 'B', 'X', 'Y'};
        printArray (charArray);
    }
    
}
