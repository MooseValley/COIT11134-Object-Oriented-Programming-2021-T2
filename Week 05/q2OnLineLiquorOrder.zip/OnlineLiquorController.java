/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w4;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author uvenu
 */
public class OnlineLiquorController implements Initializable {

    @FXML
    private CheckBox chkTooheys;
    @FXML
    private CheckBox chkVB;
    @FXML
    private CheckBox chkGoldBlock;
    @FXML
    private CheckBox chkBalter;
    @FXML
    private Slider slrTooheysQuantity;

    @FXML
    private Slider slrVBQuantity;

    @FXML
    private Slider slrGoldRockQuantity;

    @FXML
    private Slider slrBalterQuantity;

    @FXML
    private TextArea taDisplay;
    @FXML
    private Button btnOrder;
    @FXML
    private Button btnExit;
    @FXML
    private Label lblTooheysCrates;

    @FXML
    private Label lblVBCrates;

    @FXML
    private Label lblGoldRockCrates;
    @FXML
    private Label lblBalterCrates;
     @FXML
    private MenuItem miClear;

    // instance variables for order total calculation  
    private double orderTotal;
    private double balterQuantity;
    private double goldRockQuantity;
    private double tooheysQuantity;
    private double vBQuantity;
    
     /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       orderTotal = 0.0;
       this.lblBalterCrates.setText(""); 
       this.lblGoldRockCrates.setText("");
       this.lblTooheysCrates.setText("");
       this.lblVBCrates.setText("");
    }  
    
    @FXML
    public void OrderAction(){
        orderTotal = 0.0;
        
        //calculate order total based on selected liquor and number of crates
        if(this.chkBalter.isSelected()){
           orderTotal+= LiquorPrices.Balter * balterQuantity; 
        }
        if(this.chkGoldBlock.isSelected()){
           orderTotal+= LiquorPrices.GoldBlock * this.slrGoldRockQuantity.getValue();
        }
        if(this.chkTooheys.isSelected()){
           orderTotal+= LiquorPrices.Tooheys * this.slrTooheysQuantity.getValue();
        }
        if(this.chkVB.isSelected()){
           orderTotal+= LiquorPrices.VB * this.slrVBQuantity.getValue();
        }
        // display the order total in 2 decimal           
        this.taDisplay.setText(String.format("$%.2f",orderTotal));
        
    }
    
    // displaying the selected number of crates
    @FXML
    private void sliderBalterAction(){
      
    slrBalterQuantity.valueProperty().addListener(new ChangeListener<Number>() {
            public void changed(ObservableValue<? extends Number> ov,
                Number old_val, Number new_val) {
                    balterQuantity = (new_val.intValue());
                    lblBalterCrates.setText(String.format("%d",(int)balterQuantity));
            }       
        });
    }
    @FXML
    private void sliderGoldRockAction(){
      
    this.slrGoldRockQuantity.valueProperty().addListener(new ChangeListener<Number>() {
            public void changed(ObservableValue<? extends Number> ov,
                Number old_val, Number new_val) {
                    goldRockQuantity = (new_val.intValue());
                    lblGoldRockCrates.setText(String.format("%d",(int)goldRockQuantity));
            }       
        });
    }
    @FXML
    private void sliderTooheysAction(){
      
    this.slrTooheysQuantity.valueProperty().addListener(new ChangeListener<Number>() {
            public void changed(ObservableValue<? extends Number> ov,
                Number old_val, Number new_val) {
                    tooheysQuantity = (new_val.intValue());
                    lblTooheysCrates.setText(String.format("%d",(int)tooheysQuantity));
            }       
        });
    }
    @FXML
    private void sliderVBAction(){
      
    this.slrVBQuantity.valueProperty().addListener(new ChangeListener<Number>() {
            public void changed(ObservableValue<? extends Number> ov,
                Number old_val, Number new_val) {
                    vBQuantity = (new_val.intValue());
                    lblVBCrates.setText(String.format("%d",(int)vBQuantity));
            }       
        });
    }
    
    @FXML
    private void defaultSettings(){
       orderTotal = 0.0;
       this.lblBalterCrates.setText(""); 
       this.lblGoldRockCrates.setText("");
       this.lblTooheysCrates.setText("");
       this.lblVBCrates.setText("");
       
       this.slrBalterQuantity.setValue(0.0);
       this.slrGoldRockQuantity.setValue(0.0);
       this.slrTooheysQuantity.setValue(0.0);
       this.slrVBQuantity.setValue(0.0);
       this.taDisplay.setText("");
       
       this.chkBalter.setSelected(false);
       this.chkGoldBlock.setSelected(false);
       this.chkTooheys.setSelected(false);
       this.chkVB.setSelected(false);
    }
    
    @FXML
    private void clearAll(){
        this.taDisplay.setText("");
        defaultSettings();
    }
    @FXML
    private void exitButtonAction(){
        // to get confirmation for exiting the app 
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to Close?");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
              Platform.exit();
            }
        });
    }
       
}
