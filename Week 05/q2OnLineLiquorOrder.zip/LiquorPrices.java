/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w4;

/**
 *
 * @author uvenu
 */
public class LiquorPrices {
    public static final double Balter = 39.0;
    public static final double GoldBlock = 41.0;
    public static final double Tooheys = 39.0;
    public static final double VB = 39.5;
}
