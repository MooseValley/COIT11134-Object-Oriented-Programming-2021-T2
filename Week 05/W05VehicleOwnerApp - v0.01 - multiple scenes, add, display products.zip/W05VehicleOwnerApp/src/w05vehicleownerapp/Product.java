package w05vehicleownerapp;

public class Product 
{
    private String name;
    private double costPrice;
    private double soldPrice;

    public Product() {
    }

    public Product(String name, double costPrice, double soldPrice) {
        this.name = name;
        this.costPrice = costPrice;
        this.soldPrice = soldPrice;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public double getCostPrice() {
        return costPrice;
    }

    public void setCostPrice(double costPrice) {
        this.costPrice = costPrice;
    }

    public double getSoldPrice() {
        return soldPrice;
    }
    public void setSoldPrice(double soldPrice) {
        this.soldPrice = soldPrice;
    }

    @Override
    public String toString() {
        return "Name :" + name + ", Cost Price=" + costPrice + ", SoldPrice=" + soldPrice + '\n';
    }
}