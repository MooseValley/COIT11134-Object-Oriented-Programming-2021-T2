/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05vehicleownerapp;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author omalleym
 */
public class ProductFXMLController implements Initializable 
{
    protected static ArrayList<Product> productsArrayList = new ArrayList<Product>();
    
    
    @FXML private TextField nameTextField;
    @FXML private TextField costPriceTextField;
    @FXML private TextField salesPriceTextField;
    @FXML private Button quitToMainMenuButton;
    @FXML private Button quitToMainMenuButtonDAP;
    @FXML private TextArea productsTextArea;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        String outputStr = "";
        
        for (Product p : productsArrayList)
        {
            outputStr += p.toString() + "\n";
        }
        
        // Do NOT re-use controllers
        // Make a separate controller for the "ProductDisplayAllFXML.fxml"
        // and copy and paste all of this initialize() code 
        // into it's initialize() method
        // and add it's own quitToMainMenuButtonHandler
       //productsTextArea.setText (outputStr);
    }    

    @FXML 
    private void addProductButtonHandler(ActionEvent event) 
    {
        double costPrice   = 0.0;
        double salesPrice  = 0.0;
        String nameStr     = nameTextField.getText().trim();
        boolean dataValid  = true;
        
        if (nameStr.length() == 0)
        {
            dataValid = false;
            JOptionPane.showMessageDialog (null, 
                                "Error: product name cannot be blank");
        }
        
        if (dataValid == true)
        {
            // Validate costPriceTextField
            // non-blank  and also a valid floating point number
            
            if (costPriceTextField.getText().trim().length() == 0)
            {
                dataValid = false;
                JOptionPane.showMessageDialog (null, 
                                "Error: cost price cannot be blank");
            }
            else
            {
                try
                {
                   costPrice = Double.parseDouble 
                                    (costPriceTextField.getText().trim() );
                }
                catch (NumberFormatException err)
                {
                   JOptionPane.showMessageDialog (null, 
                             "Error: cost price is not a valid number.");
                   dataValid = false;
                }
            }
        }

        if (dataValid == true)
        {
            // Check next input
        }

        if (dataValid == true)
        {
            // Calculate Sold price
            salesPrice = costPrice * 1.33;
            
            // Create a Product
            // Add it into out ArrayList / Array
            Product p = new Product (nameStr, costPrice, salesPrice);
            
            // add(), get(), size(), ...
            productsArrayList.add (p);
            
            // Update the GUI
            salesPriceTextField.setText (String.format ("%.2f", salesPrice) );

            JOptionPane.showMessageDialog (null, 
                      "Success: Product added to database (" +
                      productsArrayList.size() + " added so far)");
        }
    }

    @FXML 
    private void clearProductInputsButtonHandler(ActionEvent event) 
    {
        nameTextField.setText("");
        costPriceTextField.setText("");
        salesPriceTextField.setText("");
    }

    @FXML
    private void quitToMainMenuButtonHandler(ActionEvent event) throws IOException 
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene scene = new Scene (root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene (scene);
        stage.show();
    }    
    
    //public static void setProductsArrayList (ArrayList<Product> products)
    //{
    //    productsArrayList = products;
    //}
}
