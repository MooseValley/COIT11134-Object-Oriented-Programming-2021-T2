/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05vehicleownerapp;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author omalleym
 */
public class TestResultsFXMLController implements Initializable {

    @FXML
    private TextField testResult1TextField;
    @FXML
    private TextField testResult2TextField;
    @FXML
    private ComboBox<?> productsComboBox;
    @FXML
    private Button addTestButton;
    @FXML
    private Button quitToMainMenuButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        // ProductFXMLController.productsArrayList
        int size = ProductFXMLController.productsArrayList.size();
        
        //Product[] productsArray = new Product[size];
        String[] productsArray = new String[size];
        
        for (int k = 0; k < size; k++)
        {
            productsArray [k] = ProductFXMLController.productsArrayList.
                                get(k).toString();
        }

        productsComboBox.setItems (productsArray);
    }    

    @FXML
    private void addTestButtonHandler(ActionEvent event) {
    }

    @FXML
    private void quitToMainMenuButtonHandler(ActionEvent event) {
    }
    
}
