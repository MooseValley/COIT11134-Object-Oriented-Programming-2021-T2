/**
 * COIT11134 Object Oriented Programming
 * Tutorial and Lab Exercises – Week 7
 * 
 * A proposed building application has to be verified that it 
 * is meeting the side, front and rear clearance requirements 
 * of the proposed building within the plot specified. 
 * 
 * Minimum required width clearance for a building approval 
 * is 2m (1m on each side of the building within the plot). 
 * It can be calculated by the following formula:
 *    width clearance = plot width – building width
 * 
 * Similar requirement is applied on length side to find out 
 * front and rear clearance of 2m (1m front and 1m rear).
 * 
 * Complete the missing block of codes to produce one approved 
 * and one rejected BuildingDevelopmentApplication.  
 */
package w07buildingdevelopmentapplication;

import java.time.LocalDate;

/**
 *
 * @author omalleym
 */
public class W07BuildingDevelopmentApplication 
{
    // create instance fields to store the values of plot width and length
    private double plotWidth;
    private double plotLength;
    
    // create instance fields to store the values of building width and length
    private double buildingWidth;
    private double buildingLength;
    
    // create instance fields to store the date of application	
    LocalDate dateOfApplication;
        
    boolean approved = false;
    
    // create parameterized constructor here for BuildingDevelopmentApplication
    public W07BuildingDevelopmentApplication ()
    {
        this (0, 0, 0, 0);
    }

    public W07BuildingDevelopmentApplication (double plotWidth,     double plotLength,
                                              double buildingWidth, double buildingLength)
    {
        // No data validations performed (question did not specify any).
        // If this was a real application, it would contain appropriate 
        // data validations.
        this.plotWidth      = plotWidth;
        this.plotLength     = plotLength;
        this.buildingWidth  = buildingWidth;
        this.buildingLength = buildingLength;
        
        dateOfApplication   = LocalDate.now();
    }


    // inner class to verify the building plan adheres to front, rear and sides clearance 
    class Verification
    {
        boolean valid ;
        private static final double MINIMUM_REQUIRED = 2;

        public Verification() {
            valid = false;
        }
        
        //to verify the building plan adhers to front, rear and sides clearance 
        boolean check()
        {
            if(checkWidth() && checkLength())
           {
                // valid value has to be true only when check width and check length are true
                valid = true;
            }
            return valid;
            
        }

       // to find out the required width clearance
       boolean checkWidth(){
            // complete the missing block of codes by checking required clearance
            if (plotWidth - buildingWidth >= MINIMUM_REQUIRED)
                return true;
            else
                return false;
        }
        
       // to find out the required length clearance
       boolean checkLength(){
            // complete the missing block of codes by checking required clearance
            if (plotLength - buildingLength >= MINIMUM_REQUIRED)
                return true;
            else
                return false;
        }
        
    } // class Verification
    
    
    // to display the plan is building plan is approved or not
    public void displayApproval(){
        Verification test = new Verification();
        approved = test.check();
        if(approved)
            System.out.println("Building plan Approved: " + dateOfApplication);
        else
            System.out.println("Building plan Rejected: " + dateOfApplication);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        /*
          complete the missing block of codes to create 
          BuildingDevelopmentApplication objects and invoke 
          appropriate methods to print whether it is approved 
          or rejected.
        */
        W07BuildingDevelopmentApplication app1 = 
                new W07BuildingDevelopmentApplication (20, 40, 18, 39);

        W07BuildingDevelopmentApplication app2 = 
                new W07BuildingDevelopmentApplication (20, 40, 18, 37);

        app1.displayApproval();
        app2.displayApproval();
    }
    
}
