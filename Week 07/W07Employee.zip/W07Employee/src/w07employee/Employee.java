/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w07employee;

/**
 *
 * @author omalleym
 */
public abstract class Employee implements Payable//, Comparable
{
   private String firstName;
   private String lastName;
   private String socialSecurityNumber;
   
   // missing block of codes to be completed for completing contract with interface Payable

    /**
     *
     * @return
     */
   @Override
   public abstract double getPaymentAmount();
}

