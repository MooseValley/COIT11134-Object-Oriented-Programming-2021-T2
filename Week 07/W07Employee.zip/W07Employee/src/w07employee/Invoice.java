/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w07employee;

/**
 *
 * @author omalleym
 */
// Invoice class implements Payable.

public class Invoice implements Payable//, Comparable
{

    private String partNumber;
    private String partDescription;
    private int quantity;
    private double pricePerItem;

    // four-argument constructor
    public Invoice(String part, String description, int count, double price) {
        partNumber = part;
        partDescription = description;
        setQuantity(count); // validate and store quantity
        setPricePerItem(price); // validate and store price per item
    } // end four-argument Invoice constructor

    // set part number
    public void setPartNumber(String part) {
        partNumber = part; // should validate
    } // end method setPartNumber

    // get part number
    public String getPartNumber() {
        return partNumber;
    } // end method getPartNumber

    // set description
    public void setPartDescription(String description) {
        partDescription = description; // should validate
    } // end method setPartDescription

    // get description
    public String getPartDescription() {
        return partDescription;
    } // end method getPartDescription

    // set quantity
    public void setQuantity(int count) {
        quantity = (count < 0) ? 0 : count; // quantity cannot be negative
    } // end method setQuantity

    // get quantity
    public int getQuantity() {
        return quantity;
    } // end method getQuantity

    // set price per item
    public void setPricePerItem(double price) {
        pricePerItem = (price < 0.0) ? 0.0 : price; // validate price
    } // end method setPricePerItem

    // get price per item
    public double getPricePerItem() {
        return pricePerItem;
    } // end method getPricePerItem

    // return String representation of Invoice object
    @Override
    public String toString() {
        return String.format("%s: \n%s: %s (%s) \n%s: %d \n%s: $%,.2f",
                "invoice", "part number", getPartNumber(), getPartDescription(),
                "quantity", getQuantity(), "price per item", getPricePerItem());
    } // end method toString

    // method required to carry out contract with interface Payable
    @Override
    public double getPaymentAmount() 
    {
        // total cost = quantity * price per item
        // calculate total cost of invoice and return the total cost
        // missing block of codes have to be completed
        
        return quantity * pricePerItem;
    } // end method getPaymentAmount
    
/*
    private String partNumber;      (3)
    private String partDescription; (4)
    private int quantity;           (2)
    private double pricePerItem;    (1)
*/    
    //@Override
    public int compareTo (Object object)
    {
        int result = -1; // Not the same
        
        if ((object != null) &&
            (object instanceof Invoice) )
        {
            Invoice inv2 = (Invoice) object;
            
            // Wrapper Classes
            result = ((Double)pricePerItem).compareTo(inv2.getPricePerItem () );
            
            /*
            if (pricePerItem. < inv2.getPricePerItem () )
            {
                result = -1;
            }
            else if (pricePerItem > inv2.getPricePerItem () )
            {
                result = 1;
            }
            else
            */
            if (result == 0)
            {
                // pricePerItem are the same, let's compare Quantity
                
                result = ((Integer)quantity).compareTo(inv2.getQuantity () );
                /*
                if (quantity < inv2.getQuantity () )
                {
                    result = -1;
                }
                else if (quantity > inv2.getQuantity () )
                {
                    result = 1;
                }
                else
                */
                if (result == 0)
                {
                    // pricePerItem and Quantity are the same, 
                    // let's compare partNumber
                    
                    result = partNumber.compareTo (inv2.getPartNumber() );
                    
                    if (result == 0)
                    {
                        // pricePerItem and Quantity and partNumber
                        // are the same, let's compare partDescription
                        result = partDescription.compareTo (inv2.getPartDescription() );
                    }

                }
                
                
            }
        }
        
        
        
        
        return result;
    }
    
} // end class Invoice

