/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w07employee;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author omalleym
 * 
 * This is the Week 7 workshop question with a whole bunch of extras
 * ArrayLists, implements Comparable, Wrapper Types, etc
 * 
 */
public class W07Employee extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        SalariedEmployee emp1 = new SalariedEmployee (100.0);
        SalariedEmployee emp2 = new SalariedEmployee (99.0);
        
        System.out.println ("\n" + "compareTo:");
        if (emp1.compareTo(emp2) == 0)
            System.out.println ("Emp1 = Emp2");
        else if (emp1.compareTo(emp2) < 0)
            System.out.println ("Emp1 < Emp2");
        else
            System.out.println ("Emp1 > Emp2");
        
        
        
        System.out.println ("\n" + "Basics:");
        System.out.println ("Emp1: " + emp1.toString()  +
                            " $" + emp1.getPaymentAmount() );

        Invoice inv1 = new Invoice("M123",  "Widget",  33, 14.25);
        Invoice inv2 = new Invoice("HD101", "Laptop", 3,  999.99);
        Invoice inv3 = new Invoice("HD101", "Laptoz", 3,  999.99);

        System.out.println ("inv1: " + inv1.toString()   +
                            " $" + inv1.getPaymentAmount() );
        
        System.out.println ("inv2: " + inv2.toString()   +
                            " $" + inv2.getPaymentAmount() );

        
        System.out.println ("\n" + "compareTo:");
        if (inv3.compareTo(inv2) == 0)
            System.out.println ("inv3 = inv2");
        else if (inv3.compareTo(inv2) < 0)
            System.out.println ("inv3 < inv2");
        else
            System.out.println ("inv3 > inv2");



        ArrayList<Employee> employees = new ArrayList<>();
        ArrayList<Invoice>  invoices  = new ArrayList<>();
        
        employees.add (emp1);
        invoices.add (inv1);
        invoices.add (inv2);
        
        System.out.println ("\n" + "Employees:");
        for (Employee e : employees)
        {
            System.out.println ("* " + e.toString()  +
                                " $" + e.getPaymentAmount() );
        }
        
        System.out.println ("\n" + "Invoices:");
        for (Invoice i : invoices)
        {
            System.out.println ("* " + i.toString()  +
                                " $" + i.getPaymentAmount() );
        }


        System.out.println ("\n" + "Payable = Everything:");
        ArrayList<Payable>  everything   = new ArrayList<>();
        everything.add (emp1);
        everything.add (inv1);
        everything.add (inv2);
        
        for (Payable p : everything)
        {
            System.out.println ("* " + p.toString()  +
                                " $" + p.getPaymentAmount() );
        }


        
        /*
        System.out.println ("\n" + "Object:");
        ArrayList<Object>  objects   = new ArrayList<>();
        everything.add (emp1);
        everything.add (inv1);
        everything.add (inv2);
        //everything.add (new Student ("asasas") );
        
        // ERROR: getPaymentAmount() mot implemented for every Object
        for (Object o : objects)
        {
            System.out.println ("* " + o.toString()  +
                                " $" + o.getPaymentAmount() );
        }
        */


        
        launch(args);
    }
    
}
