/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w07employee;

/**
 *
 * @author omalleym
 */
public class SalariedEmployee extends Employee
{
    private double annualSalary;    
    
    public SalariedEmployee ()
    {
        this (0.0);
    }
    
    public SalariedEmployee (double annualSalary)
    {
        this.annualSalary = annualSalary;
    }
    
    /*
        Do we need both ??
        Yes, ideally.
        getAnnualSalary () meets our obligation for all classes
        to provide Accessor methods for private instance fields.
        getPaymentAmount() meets our contract to implement Payable.
    
    */
    public double getAnnualSalary ()
    {
        return annualSalary;
    }
    
    @Override
    public double getPaymentAmount()
    {
        return annualSalary;
    }

    
    public void setAnnualSalary ()
    {
        this.annualSalary = annualSalary;
    }

    @Override
    public String toString ()
    {
        return String.format ("%.2f", annualSalary);
    }
    
    
    // if (empl.compareTo(emp2) == 0) ....
    // if (empl.compareTo(null) == 0) ....

    @Override
    public int compareTo (Object object)
    // This will work for comparing employees
    // but will fail (will not be called) when we need to Sort 
    // and do other things
    //public int compareTo (SalariedEmployee emp2)
    {
        int result = -1; // Not the same
        
        if ((object != null) &&
            (object instanceof SalariedEmployee) )
        {
            SalariedEmployee emp2 = (SalariedEmployee) object;

            if (getAnnualSalary () < emp2.getAnnualSalary () )
                result = -1;
            else if (getAnnualSalary () > emp2.getAnnualSalary () )
                result = 1;
            else
                result = 0; // Salaries the same.
        }
        
        return result;
    }
}
