/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w07employee;

/**
 *
 * @author omalleym
 * 
 * extends Comparable:
 * -> all Concrete classes that implement Payable must provide 
 *    a compareTo method.
 */
public interface Payable extends Comparable
{    
   double getPaymentAmount(); // calculate payment; no implementation
   
} // end interface Payable
