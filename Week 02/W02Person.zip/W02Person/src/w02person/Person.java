/*
Exercise 2.
Create a superclass Person and two subclasses Student and Lecturer to inherit the 
properties from Person. Person class should have two instance variables namely name 
and yearOfBirth. In addition to the inherited properties, the Student class 
should have an instance variable major whereas the 
Lecturer class should have an instance variable salary. 
The classes should have the appropriate constructors, methods and overridden 
toString methods. Create a test-driver program that can test these three classes.

 */
package w02person;

/**
 *
 * @author omalleym
 */
public class Person {
    private String name;
    private int    yearOfBirth;
    
}
