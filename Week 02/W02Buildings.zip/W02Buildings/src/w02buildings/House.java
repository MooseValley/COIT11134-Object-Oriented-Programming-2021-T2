/*
Implement the House class that extends the Building class. The House class should have the following members:
•	A field for number of bedrooms (an int)
•	A field for number of bathrooms (an int)
•	A field for number of garages (an int)
•	constructors and appropriate accessors and mutators
•	A toString method that overrides the toString method in the superclass and displays relevant information on a House object.

 */
package w02buildings;

/**
 *
 * @author omalleym
 */
public class House extends Building
{
    private int numBedrooms;
    private int numBathrooms;
    private int numGarages;   // Num Parking spaces
    
    
}
