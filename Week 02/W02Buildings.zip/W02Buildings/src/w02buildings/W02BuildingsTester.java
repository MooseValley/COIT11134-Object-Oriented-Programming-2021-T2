/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w02buildings;

/**
 *
 * @author omalleym
 */
public class W02BuildingsTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        // Create an array of Building
        // Add House and Building objects to array
        // Loops, call methods, prove everything works.
        // Calculate the Maximum, Minimum and Average number of bedrooms for all Houses.
    }
    
}
