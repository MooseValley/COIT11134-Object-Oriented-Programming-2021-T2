/*
Assume the Building class has a subclasses – House.
Implement the Building class to have the following members:
•	A field for the address of the building (a string)
•	A field for the built-in area in square metres (a double).
•	default and parameterized constructors
•	accessors and mutators
•	A toString method that displays the necessary Building detail.

 */
package w02buildings;

/**
 *
 * @author omalleym
 */
public class Building 
{
    private String address;
    private double areaSquareM;
    
    
    
}
