/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangletest;

/**
 *
 * @author omalleym
 */
// Program tests class Rectangle.
import java.util.Scanner;

public class RectangleTest
{
   public static void main( String[] args )
   {
      Scanner input = new Scanner( System.in );      
      Rectangle rectangle = new Rectangle();
      //Printing details of default valued rectangle
      System.out.println( rectangle.toString() );
      
      //Changing length and width of the new rectangle
      System.out.println("Enter Length of the new rectangle :" );
      double tempLength = input.nextDouble();
      rectangle.setLength(tempLength);
      
      System.out.println("Enter Width of the new rectangle :" );
      double tempWidth = input.nextDouble();
      rectangle.setWidth(tempWidth);
 
      //Printing the details of the new rectangle       
      System.out.println ( rectangle.toString() );
           
   } // end main
   
} // end class RectangleTest

