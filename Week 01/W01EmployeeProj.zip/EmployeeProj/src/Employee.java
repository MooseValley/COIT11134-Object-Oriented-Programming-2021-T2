/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author omalleym
 */
public class Employee 
{
//    public String name;
//    public double salary;

    private String name;   // Rules: cannot be blank, must be 2 chars or more, 
    private double salary; // Rules: must > 0, must < 10,000
   
    
    
    // Default Constructor
    public Employee ()  
    {
        //name = "";
        //salary = 0;        
        this("", 0);
    }
    
    // Parameterised Constructor #1
    public Employee (String name, double salary)  
    {
        this.name   = name;
        this.salary = salary;        
    }
    
    // Parameterised Constructor #2
    public Employee (String name)  
    {
        //this.name   = name;
        //this.salary = 0;        
        this (name, 0);
    }
    
    
    // Accessors / Getters
    
    public String getName()
    {
        return name;
    }
    
    public double getSalary()
    {
        return salary;
    }
    
    
    // Mutators / Setters
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public void setSalary (double salary)
    {
        this.salary = salary;
    }
    
    @Override
    public String toString()
    {
        return name + "\t" + "$" + String.format ("%.2f", salary);
    }

    public String toStringHeadings()
    {
        return "Name" + "\t" + "$" + "Salary";
    }
    
}
