/**
 *
 * @author omalleym
 */
public class EmployeeTester 
{
    static Employee emp1 = new Employee ();
    static Employee emp2 = new Employee ("Mike", 4.5);
    static Employee emp3 = new Employee ("Frankie");

    public static void automatedTests ()
    {
        int errorCount = 0;
        
        if (Math.abs(emp1.getSalary() - 50) > 0.0000001)
        {
            System.out.println ("Error: Emp1 Salary should be 50");
            errorCount++;
        }
        
        if (emp2.getName().compareTo ("Mike") != 0)  // ==, !=, <=, >=
        {
            System.out.println ("Error: Emp2 Name should be 'Mike'.");
            errorCount++;
        }

        System.out.println ("Errors found: " + errorCount);
    }
    
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
     
        System.out.println (emp1.toString() ); 
        System.out.println (emp2.toString() );
        System.out.println (emp3.toString() );
        
        
        emp1.setName ("Bella");
        emp1.setSalary (50);
        
        emp3.setSalary (24);
        

        System.out.println (emp1);
        System.out.println (emp2);
        System.out.println (emp3);
        
        System.out.println ("Employee #2's Salary is: " + emp2.getSalary() );
        System.out.println ("Employee #1's Name is: "   + emp1.getName() );
        
        double avgSalary = (emp1.getSalary() + emp2.getSalary() + emp3.getSalary()) / 3.0;
        System.out.println ("Average Salary is: $" + String.format ("%.2f", avgSalary) );
     
        automatedTests ();
        
        double val = 1.0 / 3.0;
        
        val = val * 3.0;
        System.out.println (val); // 0.9999999999
        
        if (Math.abs(val - 1.0) < 0.000000000001)
            System.out.println ("Val = 1.0");
    }
    
}
