/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fixeddeposit;

/**
 *
 * @author omalleym
 */
public class FixedDeposit 
{
    private static int accountNumber = 1001;

    private int    periodInYears;
    private double initialAmount;
    private int    accountId;

    // Default Constructor
    public FixedDeposit ()
    {
        this (0, 0.0); // Call Parameterised Constructor
    }
    
    // Parameterised Constructor
    public FixedDeposit (int periodInYears, double initialAmount)
    {
        accountId = accountNumber;
        accountNumber++;
        
        this.periodInYears = periodInYears;
        this.initialAmount = initialAmount;
        
        System.out.println ("Created account with accountId = " + accountId);
    }
    

    // Accessors / Getters
    
    public int getAccountId()
    {
        return accountId;
    }
    
    public double getInitialAmount()
    {
        return initialAmount;
    }

    public int getPeriodInYears()
    {
        return periodInYears;
    }


    // Mutators / Setters
    // No setAccountId - don't want anything outside this class messing with accountIds.
    // This class is handling the allocation of accountIds.
    // Don't want duplicates, gaps, etc.
    
    public void setInitialAmount(int initialAmount)
    {
        this.initialAmount = initialAmount;
    }

    public void setPeriodInYears(int periodInYears)
    {
        this.periodInYears = periodInYears;
    }

    public String toStringHeadings()
    {
        return "AccountId"      + "  " +
               "  Amount  "     + "  " +
               " Years"         + "\n" +
               "---------"      + "  " +
               "----------"     + "  " +
               "--------";
    }

    @Override
    public String toString()
    {
        return String.format ("%9d",     accountId)     + "  " +
               String.format ("%,10.2f", initialAmount) + "  " +
               String.format ("%8d",     periodInYears);
    }
}
