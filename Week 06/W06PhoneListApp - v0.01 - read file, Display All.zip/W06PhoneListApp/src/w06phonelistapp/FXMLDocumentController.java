/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w06phonelistapp;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button addButton;
    @FXML
    private Button displayButton;
    @FXML
    private Button clearButton;
    @FXML
    private Button exitButton;
    @FXML
    private Button saveButton;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addButtonHandler(ActionEvent event) 
    {
        
    }

    @FXML
    private void displayButtonHandler(ActionEvent event) throws Exception 
    {
        Utility.changeToScene (getClass(), event, "DisplayPhoneFXML.fxml");
    }

    @FXML
    private void clearButtonHandler(ActionEvent event) throws Exception 
    {
    }

    @FXML
    private void exitButtonHandler(ActionEvent event) {
    }

    @FXML
    private void saveButtonHandler(ActionEvent event) {
    }


    
}
