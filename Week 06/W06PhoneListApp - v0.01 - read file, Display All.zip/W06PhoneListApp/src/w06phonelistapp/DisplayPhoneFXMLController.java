/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w06phonelistapp;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.StringTokenizer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author omalleym
 */
public class DisplayPhoneFXMLController implements Initializable {

    @FXML
    private Button okButton;
    @FXML
    private TextArea displayTextArea;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        readDataFileAndDisplay();
    }    

    @FXML
    private void okButtonHandler(ActionEvent event) throws Exception 
    {
        Utility.changeToScene (getClass(), event, "FXMLDocument.fxml");
    }


    void readDataFileAndDisplay() 
    {
        int count = 0;            // number of entries
        String allPhone = "";     // to store all name and phone as single value

        try {
            Scanner in = new Scanner(new FileReader("staffphone.txt"));//open file
            String myEntry = "";
            String name    = "";
            String phone   = "";

            while (in.hasNextLine()) {

                myEntry = in.nextLine();
                StringTokenizer st = new StringTokenizer(myEntry, ",");

                while (st.hasMoreTokens()) {
                    name = st.nextToken();
                    phone = st.nextToken();
                }

                allPhone = allPhone + name + "  " + phone + "\n";
                count++;
            }// end of while loop
            in.close();//close file
        } 
        catch (ArrayIndexOutOfBoundsException ex) 
        {
            JOptionPane.showMessageDialog(null, "ArrayOutOfBoundsException" + ex.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);

        } 
        catch (IOException ex) 
        {
            JOptionPane.showMessageDialog(null, "file reading error" + ex.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
        }
        
        //to display the values in the text area having the fx:id taDisplay
        displayTextArea.setText(allPhone + "\n" + "Total number of phone entry is: " + count);

    }//end of readDataFileAndDisplay method
    
}
