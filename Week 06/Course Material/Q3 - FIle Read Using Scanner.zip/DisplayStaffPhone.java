/**
Solution

Programming exercise
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

//class definition
public class DisplayStaffPhone extends JFrame
{
  //GUI components

  private JTextArea displayArea;
  private JButton displayButton;
  private JButton clearButton;//optional implementation

  public DisplayStaffPhone()
  {

     super("Display Staff Phone");
     setLayout(new FlowLayout());

     displayArea=new JTextArea(15,30);
     displayButton=new JButton("Display");
     clearButton=new JButton("Clear");

     add(displayArea);

     add(displayButton);
     add(clearButton);

     displayButton.addActionListener(event -> {

      		   readDataFileAndDisplay();
	 }
	 );
     clearButton.addActionListener( event -> {
            displayArea.setText("");
     }
 	 );
  }


  // read data from a file, and display it on a textArea
  private void readDataFileAndDisplay()
  {
	   int count=0;            // how many enries
	   String allPhone="";     // all ne and phone

	   try
	   {
		   Scanner in = new Scanner(new FileReader("staffphone02.txt"));//open file

		   String myEntry = "" ;
		   String name ="";
		   String phone="";

		   while(in.hasNextLine())
		   {

				myEntry = in.nextLine();
				StringTokenizer st = new StringTokenizer(myEntry,",");

				while(st.hasMoreTokens())
				{
				    name = st.nextToken();
					phone = st.nextToken();
				}

                allPhone=allPhone+name+"  "+phone+"\n";
                count++;
			}// end of while loop
			in.close();//close file
	      }
	      catch(ArrayIndexOutOfBoundsException ex)
	      {
				JOptionPane.showMessageDialog(null,"ArrayOutOfBoundsException"+ex.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);

	      }

	       catch(IOException ex)
	      {
				JOptionPane.showMessageDialog(null,"file loading failed.."+ex.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
				System.out.println("file loading failed.");

	      }

	      displayArea.setText(allPhone+"\n"+"Total number of phone entry is: "+count);

   }//end of method


   //main method
   public static void main(String[] args)
   {
        DisplayStaffPhone dsp=new DisplayStaffPhone();
        dsp.setSize(400,400);
        dsp.setVisible(true);
   }

}//end of class definition
