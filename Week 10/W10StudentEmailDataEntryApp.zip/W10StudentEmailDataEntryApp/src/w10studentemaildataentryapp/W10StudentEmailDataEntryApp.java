/*
Author: Mike O'Malley (Lecturer / Tutor)
Date:   24-Sep-2021
Desc:   Tutorial solution: Main Application class.
Course: COIT11134 Object Oriented Programming
Week:   Workshop Exercises – Week 10

*/
package w10studentemaildataentryapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author omalleym
 */
public class W10StudentEmailDataEntryApp extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
