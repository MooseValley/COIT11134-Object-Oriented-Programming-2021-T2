/*
Author: Mike O'Malley (Lecturer / Tutor)
Date:   24-Sep-2021
Desc:   Tutorial solution: FXMLDocumentController class.
Course: COIT11134 Object Oriented Programming
Week:   Workshop Exercises – Week 10


*/
package w10studentemaildataentryapp;

import java.net.URL;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable 
{
    private LinkedList<Student> studLinkedList = new LinkedList<>();
    
    @FXML
    private TextField studentIdTextField;
    @FXML
    private TextField studentNameTextField;
    @FXML
    private TextArea textArea;
    @FXML
    private Button addButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button displayAllButton;
    @FXML
    private Button exitButton;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        textArea.setEditable (false);
        
    }    

    @FXML
    private void addButtonHandler(ActionEvent event) 
    {
        try
        {
            Student s = new Student (studentIdTextField.getText(),
                                     studentNameTextField.getText() );
            studLinkedList.add (s);

            displayAllButtonHandler (event);
        }
        catch (Exception err)
        {
            JOptionPane.showMessageDialog (null, err.getMessage() );
        }
    }

   
    @FXML
    private void deleteButtonHandler(ActionEvent event) 
    {
        String nameStr = studentNameTextField.getText().trim();
        
        ListIterator<Student> iter = studLinkedList.listIterator();
        
        boolean found = false;
        
        while ((iter.hasNext() == true) && (found == false) )
        {
            if (iter.next().getName().compareToIgnoreCase (nameStr) == 0)
            {
                iter.remove();

                found = true;                
            }
        }
        
        displayAllButtonHandler (event);

        if (found == true)
        {
            JOptionPane.showMessageDialog (null, "SUCCESS: Student with name '" + 
                                           nameStr + "' was deleted.");
        }
        else
        {
            JOptionPane.showMessageDialog (null, "ERROR: Student with name '" + 
                                           nameStr + "' could not be found.");
        }
    }

    @FXML
    private void displayAllButtonHandler(ActionEvent event) 
    {
         displayAll();
    }

    private void displayAll()
    {
        ListIterator<Student> iter = studLinkedList.listIterator();

        int count = 0;
        textArea.setText ("");

        while (iter.hasNext() == true)
        {
            textArea.appendText (iter.next() + "\n");
            count++;
        }
        textArea.appendText ("--> " + count + " students displayed."+ "\n");
    }
    
    @FXML
    private void exitButtonHandler(ActionEvent event) 
    {
        System.exit(0);
    }
    
}
