/*
Author: Mike O'Malley (Lecturer / Tutor)
Date:   24-Sep-2021
Desc:   Tutorial solution: Student class.
Course: COIT11134 Object Oriented Programming
Week:   Workshop Exercises – Week 10


*/
package w10studentemaildataentryapp;

/**
 *
 * @author omalleym
 */
public class Student 
{
    private String id;
    private String name;
    
    public Student() throws Exception
    {
        this("", "");
    }

    public Student(String id, String name) throws Exception
    {
        id   = id.trim();
        name = name.trim();
        
        if (id.length() == 0)
        {
            throw new Exception ("Error: id cannot be blank.");
        }
        if (name.length() == 0)
        {
            throw new Exception ("Error: name cannot be blank.");
        }
        
        this.id   = id;
        this.name = name;
    }
    
    public String getId()
    {
        return id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getEmail()
    {
        return id + "@cqu.edu.au";
    }

    @Override
    public String toString()
    {
        return String.format ("%-10s", id)   + 
               String.format ("%-20s", name) +
               String.format ("%-20s", getEmail() );
    }
    
}
