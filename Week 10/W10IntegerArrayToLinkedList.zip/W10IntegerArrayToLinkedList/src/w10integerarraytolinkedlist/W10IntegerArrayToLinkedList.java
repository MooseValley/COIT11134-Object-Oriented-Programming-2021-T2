/*
Author: Mike O'Malley (Lecturer / Tutor)
Date:   24-Sep-2021
Desc:   Tutorial solution.
Course: COIT11134 Object Oriented Programming
Week:   Workshop Exercises – Week 10

2. Implement a Java program that uses a LinkedList  
to store Integer objects that have the following values 
from an array

Integer [ ] arr = {-1, 17, 28, -39, 12, 6, -2, -10};

Use an iterator to traverse the LinkedList and replace 
each negative value by the corresponding positive number 
and doubled.   Print out the contents of the resulting list.  
Hint: Math.abs()

 */
package w10integerarraytolinkedlist;

import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author omalleym
 */
public class W10IntegerArrayToLinkedList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Integer [ ] arr = {-1, 17, 28, -39, 12, 6, -2, -10};
        

        System.out.print ("OLD: ");

        LinkedList<Integer> intList = new LinkedList<>();
        
        for (Integer i : arr)
        {
            System.out.print (String.format ("%3d", i) + ", ");

            if (i < 0)
            {
                i = Math.abs(i) * 2;
            }

            intList.add (i);
        }
        

        System.out.println ();
        System.out.print ("NEW: ");

        ListIterator iter = intList.listIterator ();

        while (iter.hasNext() == true)
        {
            System.out.print (String.format ("%3d", iter.next() ) + ", ");
        }
        System.out.println ();
        
    }
    
}
