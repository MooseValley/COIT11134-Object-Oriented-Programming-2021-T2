/*
Author: Mike O'Malley (Lecturer / Tutor)
Date:   24-Sep-2021
Desc:   Tutorial solution.
Course: COIT11134 Object Oriented Programming
Week:   Workshop Exercises – Week 10

1. If the following program code is executed, what contents 
would be in the resulting LinkedList  – myList?

LinkedList<String> myList = new LinkedList<String>(); 
ListIterator<String> iter;

myList.addFirst("John"); 
myList.addFirst("David"); 
iter = myList.listIterator(); 
iter.next(); 
iter.add("Peter"); 
iter.next();
iter.add("Joshua");

*/
package w10linkedlistiteratorexample;

import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author omalleym
 */
public class W10LinkedListIteratorExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        LinkedList<String> myList = new LinkedList<String>(); 
        ListIterator<String> iter;

        myList.addFirst("John"); 
        myList.addFirst("David"); 
        iter = myList.listIterator(); 
        iter.next(); 
        iter.add("Peter"); 
        iter.next();
        iter.add("Joshua");


        System.out.println ("Counter Controlled FOR loop:");
        for (int k = 0; k < myList.size(); k++)
        {
            System.out.println (myList.get(k) ); 
        }
        
        System.out.println ();
        System.out.println ("Enhanced FOR loop:");
        for (String s : myList)
        {
            System.out.println (s );
        }
        
        System.out.println ();
        System.out.println ("ListIterator:");

        iter = myList.listIterator();  // Reset back to START of list
        while (iter.hasNext() == true)
        {
            System.out.println (iter.next() );
        }
        
        
        // Loop through and change all "John" -> "Peter"
        
        System.out.println ();
        System.out.println ("ListIterator: change all \"John\" -> \"Peter\":");

        iter = myList.listIterator();  // Reset back to START of list
        while (iter.hasNext() == true)
        {
            if (iter.next().compareTo ("John") == 0)
            {
                iter.set ("Peter");
            }
        }

        System.out.println ();
        System.out.println ("ListIterator:");

        iter = myList.listIterator();  // Reset back to START of list
        while (iter.hasNext() == true)
        {
            System.out.println (iter.next() );
        }

    }

    
}
