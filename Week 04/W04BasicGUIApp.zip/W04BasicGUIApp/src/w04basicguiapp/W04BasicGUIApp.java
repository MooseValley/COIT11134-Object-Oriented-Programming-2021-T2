/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w04basicguiapp;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.Date;

/**
 *
 * @author omalleym
 */
public class W04BasicGUIApp extends JFrame
{
    JLabel outputLabel  = new JLabel();
    JButton clickButton = new JButton("Click Me");
    
    public W04BasicGUIApp()
    {
        setSize (800, 600);
        setLocation (50, 50);
        setLayout (new FlowLayout (FlowLayout.CENTER));
        
        add (clickButton);
        add (outputLabel);
        
        
        clickButton.addActionListener (event -> updateLabel() );
        
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        setVisible (true);
    }
    
    private void updateLabel()
    {
        outputLabel.setText ("" + new Date() );
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new  W04BasicGUIApp();
    }
    
}
