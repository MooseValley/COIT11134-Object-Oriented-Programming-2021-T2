/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w04javafxapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
//import javafx.scene.control.Label;
import javafx.scene.control.*;
import java.util.*;
import javax.swing.*;


/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable 
{
    private int bookingsCount;
    private int spaCount;
    private int balconyCount;
    
    @FXML
    private Label label;

    @FXML
    private Label bookingsCountLabel;

    @FXML
    private Label spaCountLabel;

    @FXML
    private Label balconyCountLabel;

    @FXML
    private TextArea textArea;

    @FXML
    private TextField nameTextField;
    
    @FXML
    private CheckBox spaCheckBox;

    @FXML
    private CheckBox balconyCheckBox;

    @FXML
    private void handleAddBookingAction(ActionEvent event) {
        //System.out.println("You clicked me!");
        //label.setText("Hello World!");
        
        if (nameTextField.getText().trim().length() == 0)
        {
            JOptionPane.showMessageDialog (null, "Error: name cannot be blank.");
        }
        else
        {
            // All data is valid ... proceed with Booking
            
            bookingsCount++;
            
            String outputStr = nameTextField.getText().trim();
            
            if (spaCheckBox.isSelected() == true)
            {
                outputStr += "  " + "Spa wanted";
                spaCount++;
            }
            else
            {
                outputStr += "  " + "No Spa";
            }

            if (balconyCheckBox.isSelected() == true)
            {
                outputStr += "  " + "Balcony wanted";
                balconyCount++;
            }
            else
            {
                outputStr += "  " + "No Balcony";
            }

            updateCountLabels();
            
            textArea.setText (outputStr + "\n" +
                              textArea.getText() );
        }
    }

    @FXML
    private void handleDateButtonAction(ActionEvent event) {
        System.out.println("Date: " + new Date() );
        label.setText("Date: " + new Date() );
        
        textArea.setText ("Date: " + new Date() + "\n" +
                          textArea.getText()  );
    }

    @FXML
    private void handleClearButtonAction(ActionEvent event) 
    {
       int result = JOptionPane.showConfirmDialog (null, "Are you sure ?", 
                                         "Clear Text Area ?", 
                                         JOptionPane.YES_NO_OPTION);
       
       if (result == JOptionPane.YES_OPTION)
       {
           textArea.setText ("");
           
           bookingsCount = 0;
           spaCount      = 0;
           balconyCount  = 0;

           updateCountLabels();
       }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    private void updateCountLabels()
    {
        double spaAvg     = 0.0;
        double balconyAvg = 0.0;

        if (bookingsCount > 0)
        {
            spaAvg     = 100.0 * spaCount     / bookingsCount;
            balconyAvg = 100.0 * balconyCount / bookingsCount;
        }
        
        bookingsCountLabel.setText ("Bookings: " + bookingsCount);
        spaCountLabel.setText      ("Spa: "      + spaCount +
                " (" + String.format ("%.1f", spaAvg) + "%)" );
        balconyCountLabel.setText  ("Balcony: "  + balconyCount +
                " (" + String.format ("%.1f", balconyAvg) + "%)" );
    }
    
}
