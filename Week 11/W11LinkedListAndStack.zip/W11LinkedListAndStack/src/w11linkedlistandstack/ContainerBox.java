/*
 Author: Mike O'Malley
 Source: ContainerBox.java
Descrtn: Data class.

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 01-Oct-2021 Mike O    Created.

*/

package w11linkedlistandstack;

/**
 *
 * @author omalleym
 */
public class ContainerBox
{

   // Class Data:
   private int     containerId;
   private String  from;
   private String  deliverTo;
   private double  value;

   // Default Consructor:
   public ContainerBox ()
   {
        this (0, "", "", 0);
   }

   // Parameterised Consructor:
   public ContainerBox (int containerId, String from, String deliverTo, double value)
   {
      this.containerId = containerId;
      this.from        = from;
      this.deliverTo   = deliverTo;
      this.value       = value;
   }

   // Accessors / Getters:

   public int getContainerId ()
   {
      return containerId;
   }

   public String getFrom ()
   {
      return from;
   }

   public String getDeliverTo ()
   {
      return deliverTo;
   }

   public double getValue ()
   {
      return value;
   }

   // Mutators / Setters:

   public void setContainerId (int containerId)
   {
      this.containerId = containerId;
   }

   public void setFrom (String from)
   {
      this.from = from;
   }

   public void setDeliverTo (String deliverTo)
   {
      this.deliverTo = deliverTo;
   }

   public void setValue (double value)
   {
      this.value = value;
   }

   @Override
   public String toString ()
   {
      return 
         containerId + "\t" + 
         from        + "\t" + 
         deliverTo   + "\t" + 
         value       + "\t" + 
         "";
   }

} // ContainerBox
