/*
 Author: Mike O'Malley
 Source: W11LinkedListAndStack.java
Descrtn: See question below.

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 01-Oct-2021 Mike O    Created.



Question:

2. LinkedList and Stack exercise.

a) Create a class called ContainerBox that has the following:
   
instance field  Data type
containerId	int
From            String
deliverTo	String
Value           double

The class should have appropriate parameterized constructor 
to receive all the instance fields; getter method for containerId; 
overrriden toString method.

b) Create a LinkedList object, named as dock, that can refer to 
the list of objects of ContainerBox class.  Add the following 
objects to the dock:

containerId	from        deliverTo                   value
1	"China Shipping"    "400 kent St"               4800.0
2	"ABC Company"       "Sydney Marketers Pty ltd"  23500.0
3	"ABC Company"       "Chrome pty Ltd"            17500.0
4	"Columbian Coffee"  "Sydney Marketers Pty ltd"  26000.0

c) Using a ListIterator, identify and remove the Containerbox 
object that has the containerId value 4.  Display the contents 
of dock on the screen.

d) Create a Stack object and push all the objects from the 
dock into the Stack object. Use pop method to display the 
contents of the Stack object on the screen.

*/

package w11linkedlistandstack;


import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Stack;

/**
 *
 * @author omalleym
 */
public class W11LinkedListAndStack {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        LinkedList<ContainerBox> containersLinkedList = new LinkedList<>();
        
        containersLinkedList.add 
            (new ContainerBox (1, "China Shipping",   "400 kent St",               4800.0) );
        containersLinkedList.add 
            (new ContainerBox (2, "ABC Company",      "Sydney Marketers Pty ltd", 23500.0) );
        containersLinkedList.add 
            (new ContainerBox (3, "ABC Company",      "Chrome pty Ltd",           17500.0) );
        containersLinkedList.add 
            (new ContainerBox (4, "Columbian Coffee", "Sydney Marketers Pty ltd", 26000.0) );
        
        ListIterator<ContainerBox> iter = containersLinkedList.listIterator(); 
        
        while (iter.hasNext() == true)
        {
            if (iter.next().getContainerId () == 4 )
            {
                iter.remove();
            }
        }
        
        Stack<ContainerBox> containerStack = new Stack<>();
        // Many ways to do this: for each, counter controlled loop, iterators, ...
        //for (int k = 0; k < containersLinkedList.size(); k++)
        iter = containersLinkedList.listIterator(); 
        while (iter.hasNext() == true)
        {
            containerStack.push(iter.next() );
        }
        
        while (containerStack.empty() == false)
        {
            System.out.println (containerStack.pop() );
        }
        
    }
    
}
