/*
 Author: Mike O'Malley
 Source: W11MyQueueTest.java
Descrtn: See question below.

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 01-Oct-2021 Mike O    Created.



Question:
1. Complete the following MyQueueTest class and find out the 
output from the following sequence of queue operations? 
Submit the Java file and the output produced by this 
tester to unit website.
 
*/
package w11myqueuetest;

/**
 *
 * @author omalleym
 */
public class W11MyQueueTest
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        // creating an IntQ object to add Integer values
        MyQueue <Integer> q = new MyQueue <>();
        int a1Mark = 12; 
        int a2Mark = 21;
        
	// Student should add an integer value (e.g., 67) to the queue q
        q.add(a1Mark); 
        q.add (101);
	
	// Student should add any three integer values (e.g., 7,24, 56) to the queue q
        q.add (22);
        q.add (13);
        q.add (2);
        
	q.add(a2Mark);
	
        // peek
        System.out.println(q.peek() + " peek value ");
	
	//remove an item from queue
        System.out.println(q.remove() +" removed value");
	
	//peek
        System.out.println(q.peek()+ " peek value ");
	
	//remove all from the queue
        System.out.println("All values in the queue are removed now");
        
        while (!q.isEmpty())
        {         
            System.out.print(q.remove() + " ");
        }
    }
}