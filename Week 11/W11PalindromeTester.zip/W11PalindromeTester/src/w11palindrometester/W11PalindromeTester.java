/*
 Author: Mike O'Malley
 Source: W11PalindromeTester.java
Descrtn: Palindrome Tester

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 01-Oct-2021 Mike O    Created.


Question:
1. (Palindrome Tester) Write a program that uses a stack 
to determine whether a string is a palindrome 
(i.e., the string is spelled identically backward and forward). 
The program should ignore space and punctuation.

 */
package w11palindrometester;

import java.util.Date;
import java.util.Stack;

/**
 *
 * @author omalleym
 */
public class W11PalindromeTester 
{
    private static boolean isPalindrome (String inOriginalStr)
    {
        String inStr = inOriginalStr;
        
        // Remove leading and trailing spaces:
        inStr = inStr.trim();

        // Change to lower case.
        inStr = inStr.toLowerCase();
        
        // Students TODO: Remove spaces, punctuation, etc.
        // Question: should we do it here or skip punctuation 
        // in the loop(s) below ?  Which is more efficient ?
        // What could we do to improve efficiency ?
        // Strings are SUPER SLOW in Java - see example in main below.
        // Use StringBuilder or StringBuffer instead where possible.
        // Could this code be better ?
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < inStr.length(); k++)
        {
            // Students TODO: something is not right here ...  
            // does not remove all unwanted chars ...
            if (Character.isLetter (inStr.charAt (k) ) == true )
                sb.append (inStr.charAt (k));
        }
        
        inStr = sb.toString();
        
        
        // Add each char to a Stack
        Stack<Character> stack = new Stack<>();
        
        // Students TODO: Do we have to loop through the entire String ?
        for (int k = 0; k < inStr.length(); k++)
        {
            stack.push (inStr.charAt (k) );
        }
        
        // Compare Stack VS String
        // If enough chars match => Palindrome - how many are enough ??  :)
        
        boolean result = true; // Assume true and try and prove wrong.
        
        // Students TODO: Do we have to loop through the entire String ?
        for (int k = 0; k < inStr.length(); k++)
        {
            if (stack.pop() != inStr.charAt (k) )
                result = false; // Not a Palindrome.
        }
        
        if (result == true)
            System.out.println (inOriginalStr + " is a palindrome.");
        else
            System.out.println (inOriginalStr + " is NOT a palindrome.");
        
        return result;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
     
        isPalindrome ("racecar");
        isPalindrome ("Dammit, I’m Mad!!");
        
        /*
        String outStr = "";
        System.out.println ("START: " + new Date() );
        for (int k = 0; k < 1_00_000; k++)
        {
            outStr += k;
        }
        System.out.println ("END: " + new Date() );
        
        
        StringBuilder sb = new StringBuilder ();
        System.out.println ("START: " + new Date() );
        for (int k = 0; k < 1_00_000; k++)
        {
            sb.append (k);
        }
        System.out.println ("END: " + new Date() );
        */
    }
    
}
