/*
1. Define an Employee Class. The Employee class should have 
three instance variables namely firstName, lastName and socialSecurityNumber; 
appropriate constructor, get and set methods; an overridden toString method; 
and an abstract method earnings to return a double value.
 */
package w03employee;

/**
 *
 * @author omalleym
 */
public abstract class Employee
{
    // three instance variables namely firstName, lastName and socialSecurityNumber; 
    private String firstName;
    private String lastName;
    private String socialSecurityNumber;
            
    
    public Employee ()
    {
        this("unknown", "unknown", "unknown"); // Call PC
    }
    
    public Employee (String firstName, String lastName, String socialSecurityNumber)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
    }
    
    // Accessors/ Getters
    public String getFirstName ()
    {
        return firstName;
    }

    public String getLastName ()
    {
        return lastName;
    }

    public String getSocialSecurityNumber ()
    {
        return socialSecurityNumber;
    }
    
    // Mutators / Setters
    public void setFirstName (String firstName)
    {
        this.firstName = firstName;
    }

    public void setLastName (String lastName)
    {
        this.lastName = lastName;
    }

    public void setSocialSecurityNumber (String socialSecurityNumber)
    {
        this.socialSecurityNumber = socialSecurityNumber;
    }
    
    public static String toStringHeadings()
    {
        return String.format ("%-20s", "First Name") +
               String.format ("%-20s", "Last  Name") +
               String.format ("%-10s", "SSN")     +
               String.format ("%10s",  "Wage")    + "  " +
               String.format ("%7s",   "Pieces")  + "  " +
               String.format ("%8s",   "Earnings" );
    }

    @Override
    public String toString ()
    {
        return String.format ("%-20s", firstName) +
               String.format ("%-20s", lastName) +
               String.format ("%-10s", socialSecurityNumber);
    }
    
    abstract double earnings ();
}
