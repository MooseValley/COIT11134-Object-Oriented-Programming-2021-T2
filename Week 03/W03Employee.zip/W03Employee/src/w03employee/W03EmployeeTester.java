/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w03employee;

/**
 *
 * @author omalleym
 */
public class W03EmployeeTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        //Employee e1 = new Employee ("Mike", "OMalley", "123456");
        //System.out.println (e1.toString() );
        
        //PieceWorker p1 = new PieceWorker ("Mike", "OMalley", "123456", 0.5, 500);
        //System.out.println (p1.toString() );
        
        Employee[] employees = new Employee [10];
        
        employees[0] = new PieceWorker      ("Mike",    "OMalley", "123456", 0.5, 500);
        employees[1] = new PieceWorker      ("Frankie", "Hound",   "777665", 0.9, 300);
        employees[2] = new PieceWorker      ("Bella",   "Smith",   "887661", 1.1, 200);
        employees[9] = new SalariedEmployee ("Sam",     "Cool",    "555123", 432.0);
        
        
        
        // Display all Employees
        System.out.println (Employee.toStringHeadings() );
        for (Employee v : employees)
        {
            if (v != null)
                System.out.println (v.toString() );
        }
        
        // Calculate and display the average earnings.
        double totalEarnings = 0.0;
        int    count         = 0;
        double avgEarnings   = 0.0;
        for (Employee v : employees)
        {
            if (v != null)
            {
                totalEarnings += v.earnings();
                count++;
            }
        }
        if (count > 0)
            avgEarnings = totalEarnings / count;
        System.out.println ("Average Earnings: " + String.format ("$%.2f", avgEarnings) );
        
        
        // Discussion:
        // Validation - what goes where

        
        /*
            Suggested homework:
            * Convert this to ArrayList
            * Calculate the Yearly Payroll - 52 weeks in a year
            * Add Manager class - weekly salary + yearly bonus
        
        
        */
        
    }
    
}
