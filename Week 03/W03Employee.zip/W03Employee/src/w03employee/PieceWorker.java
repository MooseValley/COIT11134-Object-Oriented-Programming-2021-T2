/*
Create a subclass PieceWorker extending the above Employee class. 
The class PieceWorker should have private instance variables 
wage (to store the employee’s wage per piece) and 
pieces (to store the number of pieces produced); 
appropriate constructor, get and set methods; an overridden toString method; 
concrete implementation of method earnings to calculate and
return the PieceWorker’s  earnings  (wage X pieces).
 */
package w03employee;

/**
 *
 * @author omalleym
 */
public class PieceWorker extends Employee
{
    private double wage;
    private int pieces;
    
    public PieceWorker ()
    {
        this("unknown", "unknown", "unknown", 0.0, 0); // Call PC
    }
    public PieceWorker (String firstName, String lastName, String socialSecurityNumber, 
                        double wage, int pieces)
    {
        super (firstName, lastName, socialSecurityNumber);
        
        this.wage   = wage;
        this.pieces = pieces;
    }
    
    public double getWage ()
    {
        return wage;
    }
    public int getPieces ()
    {        
        return pieces;
    }
    
    public void setWage(double wage)
    {        
        this.wage = wage;
    }    
    public void setPieces (int pieces)
    {        
        this.pieces = pieces;
    }
    
    @Override
    public String toString()
    {
        return super.toString()                 + "  " +
               String.format("$%7.2f", wage)    + "  " +
               String.format("%7d",    pieces)  + "  " +
               String.format("$%7.2f", earnings() );
    }
    
    @Override
    public double earnings ()
    {
        return wage * pieces;
    }
}
