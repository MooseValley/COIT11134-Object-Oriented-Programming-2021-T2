/*
2. Create a subclass SalariedEmployee extending the above Employee class.  
The SalariedEmployee class should have salary field (to store weekly salary); 
appropriate constructor, get and set methods; an overridden toString method; 
and concrete implementation of method earnings to return the weekly salary.
 */
package w03employee;

/**
 *
 * @author omalleym
 */
public class SalariedEmployee extends Employee
{
    private double weeklySalary;
    
    public SalariedEmployee()
    {
        this ("unknown", "unknown", "unknown", 0.0);
    }
    
    public SalariedEmployee (String firstName, String lastName, String socialSecurityNumber, 
                             double weeklySalary)
    {
        super (firstName, lastName, socialSecurityNumber);
        this.weeklySalary = weeklySalary;
    }

    public double getWeeklySalary() 
    {
        return weeklySalary;
    }

    public void setWeeklySalary(double weeklySalary) 
    {
        this.weeklySalary = weeklySalary;
    }

    @Override
    public String toString()
    {
        return super.toString()              + "  " +
               String.format("%8s",   "")    + "  " +
               String.format("%7s",   "")    + "  " +
               String.format("$%7.2f", earnings () );
    }
    
    @Override
    public double earnings ()
    {
        return weeklySalary;
    }
    
}
