/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w03patient;

/**
 *
 * @author omalleym
 */
public abstract class Patient 
{
    private String name;
    //private type attribuite2;
    //private type attribuite3;
    
    public Patient ()
    {
        this("");
    }
    
    public Patient (String name)
    {
        this.name = name;
    }
    
    
    public String getName()
    {
        return name;
    }
    
    public abstract void Operation2 ();
    
}
