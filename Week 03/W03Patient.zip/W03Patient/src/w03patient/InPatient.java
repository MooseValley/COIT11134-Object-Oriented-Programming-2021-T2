/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w03patient;

import java.util.*;

/**
 *
 * @author omalleym
 */
public class InPatient extends Patient
{
    // Question is NOT clear at all.
    
    
    private int bedNum;
    //private type attribute2;
    private Date adminDate;

    public void Operation1()
    {

    }  

    public void Operation2()
    {

    }  

    // ?????

}
