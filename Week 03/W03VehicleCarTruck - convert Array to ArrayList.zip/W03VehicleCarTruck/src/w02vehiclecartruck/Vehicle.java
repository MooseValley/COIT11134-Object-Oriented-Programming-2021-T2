/*
 Assume the Vehicle class has two subclasses – Car and Truck. Implement the
Vehicle class to have the following members:
•	A field for the vehicle model description (a string).
•	A field for the year and month that the vehicle was built (a string).
•	A field for the fuel economy per litre (a double).
•	A constructor and appropriate accessors and mutators.
•	A toString method that displays the necessary vehicle detail.

 */
package w02vehiclecartruck;

/**
 *
 * @author omalleym
 */
public class Vehicle 
{
    private String model;
    private String yearMonth;
    private double fuelEconomy; // Km/Litre
    
    // Default Constructor
    public Vehicle ()
    {
        //this.model = "";
        //model = "";
        this("", "", 0.0); // Call Parameterised Constructor
    }
    
    // Parameterised Constructor
    public Vehicle (String model, String yearMonth, double fuelEconomy)
    {
        this.model       = model;
        this.yearMonth   = yearMonth;
        this.fuelEconomy = fuelEconomy;
    }
    
    // Accessors / Getters
    public String getModel()
    {
        return model;        
    }
    
    public String getYearMonth()
    {
        return yearMonth;        
    }

    public double getFuelEconomy()
    {
        return fuelEconomy;        
    }
    
    @Override
    public String toString()
    {
        //return model + "\t" + yearMonth + "\t" + fuelEconomy;
        return String.format ("%-10s", getClass().getSimpleName() ) +
               String.format ("%-20s", model)     + 
               String.format ("%-20s", yearMonth) + 
               String.format ("%8.2f", fuelEconomy);
    }
    
    // Mutators / Setters
    
    public void setModel(String model)
    {
        this.model = model;
    }
    
    public void setYearMonth (String yearMonth)
    {
        this.yearMonth = yearMonth;
    }
    
    public void setFuelEconomy (double fuelEconomy)
    {
        this.fuelEconomy = fuelEconomy;
    }
            
    
}
