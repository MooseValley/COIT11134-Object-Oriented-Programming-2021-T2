/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w09allexpenses;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class W09AllExpenses {

    /**
     * @param args the command line arguments
     */
    public static void main( String [] args)
    {
        /*
        Tour tour1  =  new Tour("Sydney",         250);
        Tour tour2  =  new Tour("National Parks", 110.75);

        ArrayList<Tour> allTours = new ArrayList<Tour>();
        allTours.add(tour1);
        allTours.add(tour2);

        AllExpense<Tour> te = new AllExpense<Tour>(allTours);
        System.out.println( "Total of Tour Expenses : $"+te.findTotal());

        Study study1  =  new Study("COIT29222", "Programming", 2500);
        Study study2  =  new Study("COIT20247", "Database",    2300.50);

        ArrayList<Study> allStudy = new ArrayList<Study>();
        allStudy.add(study1);
        allStudy.add(study2);

        AllExpense<Study> se = new AllExpense<Study>(allStudy);
        System.out.println( "Total of Study Expenses : $"+se.findTotal());

        System.out.println( "Total of Study and tour Expenses : $"+(se.findTotal() + te.findTotal()) );


        System.out.println( "Highest Study Expenses : $" + se.findHighest());
        System.out.println( "Lowest  Study Expenses : $" + se.findLowest());
        
        */

        Tour tour1  =  new Tour("Sydney",         250);
        Tour tour2  =  new Tour("National Parks", 110.75);


        AllExpense<Tour> allTours = new AllExpense<Tour>();
        allTours.add(tour1);
        allTours.add(tour2);

        System.out.println( "Total of Tour Expenses : $" + allTours.findTotal());



        Study study1  =  new Study("COIT29222", "Programming", 2500);
        Study study2  =  new Study("COIT20247", "Database",    2300.50);

        AllExpense<Study> allStudy = new AllExpense<Study>();
        allStudy.add(study1);
        allStudy.add(study2);

        System.out.println( "Total of Study Expenses : $"+allStudy.findTotal());

        System.out.println( "Total of Study and tour Expenses : $"+
                           (allStudy.findTotal() + allTours.findTotal()) );


        System.out.println( "Highest Study Expenses : $" + allStudy.findHighest());
        System.out.println( "Lowest  Study Expenses : $" + allStudy.findLowest());
        
        
        // One object to contain everything
        AllExpense<Needable> allExpenses = new AllExpense<Needable>();
        allExpenses.add(tour1);
        allExpenses.add(tour2);
        allExpenses.add(study1);
        allExpenses.add(study2);
        
        System.out.println( "Total of ALL Expenses : $" + allExpenses.findTotal());

    }
    
}
