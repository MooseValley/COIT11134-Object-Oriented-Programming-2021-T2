package w09allexpenses;

import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SIERP1
 */
public class AllExpense<T extends Needable> {
    private ArrayList<T> allList;//

    public AllExpense() 
    {
        allList = new ArrayList<T>();
    }

    /*
    public AllExpense(ArrayList<T> aList) 
    {
        //this.allList = aList;
    }
    */
    
    public void add (T data)
    {
        allList.add (data);
    }

/*
    // Extras to help with Assignment 2 ...
    // if students want to go the extra mile and use
    // Generic classes / generic methods ....
    public void addToComboBox (ComboBox combo)
    {
        for(T x: allList)
            combo.add ......
        
    }
    
    public void saveToFile (String filenameStr)
    {
        try (Formatter .....)
            
        })
    }

    public void loadFromFile (String filenameStr, int linesPerObject)
    {
        try (Scanner  ..... )
            
        })
    }
*/

    /**
     *
     * @return total of all tour expenses
     */
    public double findTotal(){
        double total = 0;
        for(T x: allList)
            total = x.getCost() + total;
        return total;

    }
    
    public double findLowest()
    {
        // or Double.MIN_VALUE ??? Are you SURE ???
        double lowest = allList.get(0).getCost(); 
        
        for(T x: allList)
        {
            if (lowest > x.getCost())
                lowest = x.getCost();
        }

        return lowest;
    }
    
    public double findHighest()
    {
        // or Double.MAX_VALUE
        double highest = allList.get(0).getCost(); 
        
        for(T x: allList)
        {
            if (highest < x.getCost())
                highest = x.getCost();
        }

        return highest;
    }

}
