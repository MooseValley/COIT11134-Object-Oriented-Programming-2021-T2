/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w09tourtest;

/**
 * @author omalleym
 * 
 * Number
 * - Integer
 * - Double
 * 
 * Restrict T to objects of type Number or children of Number.
 * 
 */
public class Tour <T extends Number>  
{
    String name; 
    T price;

    public Tour( String name, T price) 
    {
        this.name = name;
        this.price = price;
    }

    public String getName() 
    { 
        return name;
    }

    public void setName( String name) 
    { 
        this.name = name;
    }

    public T getPrice() 
    { 
        return price;
    }

    public void setPrice(T price) 
    {
        this.price = price;
    }

    @Override
    public String toString()  
    {
        return "Name =  "  +  name +  ", price =  $" +  price +   '\n';
    }

}// end of class Tour

