/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w09tourtest;

/**
 *
 * @author omalleym
 */
public class W09TourTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        /*
        Tour tour1  =  new Tour("Sydney", 250);
        Tour tour2  =  new Tour("National Parks", 125);
        */
                
        Tour<Integer> tour1 = new Tour<Integer>("Sydney",         250);
        Tour<Double>  tour2 = new Tour<Double> ("National Parks", 110.75);

        System.out.println(tour1); 
        System.out.println(tour2);

        //Number n = (Number)100;
        //Tour<Double>  tour5 = new Tour<Double> ("National Parks", n);

        /*
        // These were allowed / fine until we restricted what T could be in the Tour class.
        //
        Tour<String>  tour3 = new Tour<String>  ("Sydney", "Hello");
        Tour<Student> tour4 = new Tour<Student> ("Mike",   new Student(101, "Michael") );

        System.out.println(tour3); 
        System.out.println(tour4);
        */

    }
    
}
