/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w2x;

/**
 *
 * @author uvenu
 */
/*
public class Tour  {

    String name; 
    String activity;
    Integer price;

    public Tour(String name, String activity, Integer price) {
        this.name = name;
        this.activity = activity;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    
    @Override
    public String toString()  {
    return "Name : "  +  name +  "\nActivity : "+ activity +"\nPrice : $" +  price +   '\n';
    }

}// end of class Tour
*/
public class Tour<T>  {

    String name; 
    String activity;
    T price;

    public Tour(String name, String activity, T price) {
        this.name = name;
        this.activity = activity;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public T getPrice() {
        return price;
    }

    public void setPrice(T price) {
        this.price = price;
    }

    
    @Override
    public String toString()  {
    return "Name : "  +  name +  "\nActivity : "+ activity +"\nPrice : $" +  price +   '\n';
    }

}// end of class Tour
