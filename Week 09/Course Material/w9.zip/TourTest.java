/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w2x;

/**
 *
 * @author uvenu
 */

public class TourTest {
    public static void main( String []   args)
    {
        Tour tour1  =  new Tour("Sydney","Opera house visit", 250);
        Tour tour2  =  new Tour("National Parks", "Trekking", 125.5);

        System.out.println( tour1); 
        System.out.println( tour2);
    }

} // end of class TourTest1


